import * as urlparse from "url-parse";
export class UniversalLink {
    constructor(link) {
        const url = urlparse(link, true);
        this.href = url.href;
        this.origin = url.origin;
        this.pathname = url.pathname;
        this.query = url.query;
    }
}
let universalLink;
export function setUniversalLink(link) {
    universalLink = new UniversalLink(link);
}
export function getUniversalLink() {
    return universalLink;
}
export let callback;
export function registerUniversalLinkCallback(cb) {
    callback = cb;
}
export function getRegisteredCallback() {
    return callback;
}
//# sourceMappingURL=plugin-universal-links.common.js.map