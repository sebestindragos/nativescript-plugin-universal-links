import { Application } from "@nativescript/core";
import { setUniversalLink, getRegisteredCallback, getUniversalLink } from "./plugin-universal-links.common";
export { getUniversalLink, registerUniversalLinkCallback } from "./plugin-universal-links.common";
var CustomUIApplicationDelegate = /** @class */ (function (_super) {
    __extends(CustomUIApplicationDelegate, _super);
    function CustomUIApplicationDelegate() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    CustomUIApplicationDelegate.ObjCProtocols = [UIApplicationDelegate];
    return CustomUIApplicationDelegate;
}(UIResponder));
let delegate = Application.ios.delegate;
if (!delegate) {
    delegate = Application.ios.delegate = CustomUIApplicationDelegate;
}
function addDelegateHandler(classRef, methodName, handler) {
    const crtHandler = classRef.prototype[methodName];
    classRef.prototype[methodName] = function () {
        const args = Array.from(arguments);
        if (crtHandler) {
            const result = crtHandler.apply(this, args);
            args.push(result);
        }
        return handler.apply(this, args);
    };
}
addDelegateHandler(delegate, "applicationContinueUserActivityRestorationHandler", (_application, userActivity) => {
    try {
        if (userActivity.activityType === NSUserActivityTypeBrowsingWeb) {
            setUniversalLink(userActivity.webpageURL.absoluteString);
            const callback = getRegisteredCallback();
            if (callback)
                callback(getUniversalLink());
        }
        return true;
    }
    catch (error) {
        return false;
    }
});
//# sourceMappingURL=plugin-universal-links.ios.js.map